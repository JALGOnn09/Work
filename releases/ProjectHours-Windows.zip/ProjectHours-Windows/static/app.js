'use strict';
const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const formatHours = (value) => new Intl.NumberFormat('ru-RU', {maximumFractionDigits:2}).format(value);
const now = new Date();
const state = {view:'reports', month:`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`, employee:'', projects:[], employees:[], report:{entries:[],totals:{closed:0,pending:0,all:0,count:0,closed_count:0}}, status:'all', search:'', loaded:false};
let editor = null;
let toastTimeout;
let loadVersion = 0;
let loading = false;

async function api(path, method='GET', data) {
  const response = await fetch(path, {method, headers:data === undefined ? {} : {'Content-Type':'application/json'}, body:data === undefined ? undefined : JSON.stringify(data)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Не удалось выполнить запрос.');
  return result;
}

function toast(message) {
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => { $('#toast').hidden = true; }, 4000);
}

function query() {
  const params = new URLSearchParams({month:state.month});
  if (state.employee) params.set('employee', state.employee);
  return params.toString();
}

async function load() {
  const version = ++loadVersion;
  loading = true;
  $('#primary-action').disabled = true;
  $('#copy-month').disabled = true;
  $('#reports-view').setAttribute('aria-busy', 'true');
  try {
    const [projects, employees, report] = await Promise.all([api('/api/projects'), api('/api/employees'), api('/api/report?' + query())]);
    if (version !== loadVersion) return;
    Object.assign(state, {projects, employees, report, loaded:true});
    $('#load-error').hidden = true;
    render();
  } catch (error) {
    if (version !== loadVersion) return;
    $('#load-error').hidden = false;
    toast(error.message || 'Нет связи с сервером. Повторите загрузку.');
  } finally {
    if (version === loadVersion) {
      loading = false;
      $('#primary-action').disabled = !state.loaded;
      $('#copy-month').disabled = !state.loaded;
      $('#reports-view').setAttribute('aria-busy', 'false');
    }
  }
}

function monthTitle() {
  const [year, month] = state.month.split('-').map(Number);
  const date = new Date(0);
  date.setFullYear(year, month-1, 1);
  const title = new Intl.DateTimeFormat('ru-RU', {month:'long', year:'numeric'}).format(date).replace(/ г\.$/, '');
  return title[0].toUpperCase() + title.slice(1);
}

function render() {
  $('#project-count').textContent = state.projects.filter(p => !p.archived).length;
  $('#employee-count').textContent = state.employees.filter(p => !p.archived).length;
  const title = {reports:'Месячные отчёты', projects:'Проекты', employees:'Команда'}[state.view];
  $('#page-title').textContent = title;
  $('#breadcrumb').textContent = title;
  $('#page-description').textContent = {reports:'Вся работа за месяц. В итог идут только закрытые проекты.', projects:'Общий справочник проектов. Добавляйте их в отчёты каждый месяц.', employees:'Отдельный отчёт каждого сотрудника и общий итог команды.'}[state.view];
  $('#primary-action').innerHTML = `<span>＋</span> ${state.view === 'reports' ? 'Добавить в отчёт' : state.view === 'projects' ? 'Добавить проект' : 'Добавить сотрудника'}`;
  document.querySelectorAll('[data-view]').forEach(button => {button.classList.toggle('active', button.dataset.view === state.view); button.setAttribute('aria-current',button.dataset.view === state.view ? 'page' : 'false');});
  $('#reports-view').hidden = state.view !== 'reports';
  $('#catalog-view').hidden = state.view === 'reports';
  $('#month').value = state.month;
  $('#month-title').textContent = monthTitle();
  $('#employee-filter').innerHTML = '<option value="">Вся команда</option>' + state.employees.map(e => `<option value="${e.id}">${escapeHTML(e.name)}${e.archived ? ' · архив' : ''}</option>`).join('');
  $('#employee-filter').value = state.employee;
  $('#export').href = '/api/export?' + query();
  $('#copy-month').disabled = !state.loaded;
  if (state.view === 'reports') renderReport(); else renderCatalog();
}

function renderReport() {
  const totals = state.report.totals;
  $('#closed-hours').textContent = formatHours(totals.closed);
  $('#pending-hours').textContent = formatHours(totals.pending);
  $('#entry-count').textContent = totals.count;
  $('#entry-caption').textContent = `${totals.closed_count} закрытых · ${totals.count-totals.closed_count} незакрытых`;
  $('#report-subtitle').textContent = (state.employee ? state.employees.find(e => String(e.id) === state.employee)?.name : 'Вся команда') + ' · ' + monthTitle();
  const term = state.search.toLocaleLowerCase('ru');
  const rows = state.report.entries.filter(row => (state.status === 'all' || (state.status === 'closed') === row.closed) && `${row.project} ${row.client} ${row.employee} ${row.note}`.toLocaleLowerCase('ru').includes(term));
  $('#rows-count').textContent = rows.length === totals.count ? rows.length : `${rows.length} из ${totals.count}`;
  $('#report-body').innerHTML = rows.map((row, index) => `<tr class="${row.closed ? 'closed' : 'pending'}-row"><td>${String(index+1).padStart(2,'0')}</td><td><div class="project-name">${escapeHTML(row.project)}</div>${row.client ? `<div class="project-meta">${escapeHTML(row.client)}</div>` : ''}${row.note ? `<span class="entry-note">${escapeHTML(row.note)}</span>` : ''}</td><td class="employee-name">${escapeHTML(row.employee)}</td><td><span class="badge ${row.closed ? 'closed' : 'pending'}">${row.closed ? '✓ Закрыт' : '◷ Не закрыт'}</span></td><td class="numeric hours-cell">${formatHours(row.hours)}</td><td class="numeric counted-cell">${row.closed ? formatHours(row.hours) : '—'}</td><td><div class="row-actions"><button class="row-action" data-edit-entry="${row.id}" aria-label="Изменить ${escapeHTML(row.project)} для ${escapeHTML(row.employee)}" title="Изменить">✎</button><button class="row-action delete" data-delete-entry="${row.id}" aria-label="Удалить ${escapeHTML(row.project)} из отчёта" title="Удалить из отчёта">×</button></div></td></tr>`).join('');
  $('#report-footer').hidden = !rows.length;
  $('#all-hours-footer').textContent = formatHours(totals.all) + ' ч';
  $('#closed-hours-footer').textContent = formatHours(totals.closed) + ' ч';
  $('#report-empty').hidden = rows.length > 0;
  if (!rows.length) {
    let title, text, actions = '';
    if (totals.count) {
      title = 'Совпадений не найдено'; text = 'Попробуйте другой запрос или сбросьте фильтры.';
      actions = '<button class="button secondary" data-reset-filters>Сбросить фильтры</button>';
    } else if (!state.employees.some(e => !e.archived) || !state.projects.some(p => !p.archived)) {
      title = 'Начните с команды и проектов'; text = 'Добавьте сотрудников и проекты, затем заполните первый месячный отчёт.';
      actions = '<button class="button secondary" data-new-catalog="employees">＋ Сотрудник</button><button class="button secondary" data-new-catalog="projects">＋ Проект</button>';
    } else {
      title = 'Месяц начинается с первой записи'; text = 'Добавьте проект, выберите сотрудника и укажите часы вручную.';
      actions = '<button class="button primary" data-new-entry>＋ Добавить в отчёт</button>';
    }
    $('#report-empty').innerHTML = `<div class="empty-symbol">▤</div><h3>${title}</h3><p>${text}</p>${actions}`;
  }
  document.querySelectorAll('[data-status]').forEach(button => {button.classList.toggle('active',button.dataset.status === state.status);button.setAttribute('aria-pressed', String(button.dataset.status === state.status));});
}

function renderCatalog() {
  const items = state[state.view];
  const employees = state.view === 'employees';
  $('#catalog-list').innerHTML = items.map(item => `<article class="catalog-card ${item.archived ? 'archived' : ''}"><div class="catalog-avatar">${escapeHTML(item.name.slice(0,2).toUpperCase())}</div><h2>${escapeHTML(item.name)}</h2><p>${escapeHTML(item[employees ? 'role' : 'client'] || (employees ? 'Сотрудник команды' : 'Заказчик не указан'))}</p><div class="card-footer"><span>${item.archived ? 'В архиве' : '● Активен'}</span><button class="text-button" data-edit-catalog="${item.id}">Изменить</button></div></article>`).join('');
  $('#catalog-empty').hidden = items.length > 0;
  $('#catalog-empty').innerHTML = `<div class="empty-symbol">${employees ? '♧' : '▦'}</div><h3>${employees ? 'Ваша команда будет здесь' : 'Место для ваших проектов'}</h3><p>${employees ? 'Добавьте сотрудников, чтобы вести отдельные отчёты по часам.' : 'Создайте справочник проектов — его можно использовать каждый месяц.'}</p><button class="button primary" data-new-catalog="${state.view}">＋ ${employees ? 'Добавить сотрудника' : 'Добавить проект'}</button>`;
}

function field(name, title, value='', extras='') {
  return `<label class="field">${title}<input name="${name}" value="${escapeHTML(value)}" ${extras}></label>`;
}

function openCatalog(kind, id) {
  if (loading || !state.loaded) return;
  const item = state[kind].find(row => row.id === id);
  const employees = kind === 'employees';
  editor = {kind, id};
  $('#editor-title').textContent = `${item ? 'Изменить' : 'Новый'} ${employees ? (item ? 'сотрудника' : 'сотрудник') : 'проект'}`;
  const nameField = employees ? field('name', 'Имя сотрудника', item?.name, 'required maxlength="160" placeholder="Например, Анна Смирнова"') : `<label class="field">Проект / описание работ<textarea name="name" required maxlength="1000" placeholder="Название, заказчик, номер проекта или заявки">${escapeHTML(item?.name || '')}</textarea><small>Можно вставить полное описание из Excel — до 1000 символов.</small></label>`;
  $('#editor-fields').innerHTML = nameField + field(employees ? 'role' : 'client', employees ? 'Должность · необязательно' : 'Заказчик · необязательно', item?.[employees ? 'role' : 'client'], 'maxlength="160"') + (item ? `<label class="check-field"><input type="checkbox" name="archived" ${item.archived ? 'checked' : ''}> В архиве — не добавлять в новые отчёты</label><p class="project-meta">Архив сохраняет уже заполненные отчёты.</p>` : '');
  showEditor();
}

function openEntry(id) {
  if (loading || !state.loaded) return;
  const item = state.report.entries.find(row => row.id === id);
  const employees = state.employees.filter(e => !e.archived || e.id === item?.employee_id);
  const projects = state.projects.filter(p => !p.archived || p.id === item?.project_id);
  if (!employees.length || !projects.length) {
    toast('Сначала добавьте сотрудника и проект в справочники.');
    state.view = employees.length ? 'projects' : 'employees';
    render();
    return;
  }
  editor = {kind:'entries', id};
  $('#editor-title').textContent = item ? 'Изменить запись' : 'Добавить в отчёт';
  const employee = item?.employee_id || state.employee;
  $('#editor-fields').innerHTML = `<label class="field">Сотрудник<select name="employee_id" required>${employees.map(e => `<option value="${e.id}" ${String(e.id) === String(employee) ? 'selected' : ''}>${escapeHTML(e.name)}</option>`).join('')}</select></label><label class="field">Проект<select name="project_id" required>${projects.map(p => `<option value="${p.id}" ${p.id === item?.project_id ? 'selected' : ''}>${escapeHTML(p.name)}${p.client ? ' · ' + escapeHTML(p.client) : ''}</option>`).join('')}</select></label><div class="field-row">${field('month', 'Месяц отчёта', state.month, 'type="month" required min="0001-01" max="9999-12"')}${field('hours','Часы', item ? String(item.hours).replace('.',',') : '', 'required inputmode="decimal" placeholder="Например, 12,5" maxlength="12"')}</div><div class="field">Статус проекта<div class="status-options"><label class="status-choice"><input type="radio" name="closed" value="false" ${!item?.closed ? 'checked' : ''}> Не закрыт</label><label class="status-choice"><input type="radio" name="closed" value="true" ${item?.closed ? 'checked' : ''}> Закрыт</label></div><small>В итог месяца попадут только часы закрытого проекта.</small></div><label class="field">Комментарий · необязательно<textarea name="note" maxlength="1000" placeholder="Что было сделано по проекту">${escapeHTML(item?.note || '')}</textarea></label>`;
  showEditor();
}

function showEditor() {
  $('#form-error').hidden = true;
  $('#save-button').disabled = false;
  $('#editor').showModal();
  const input = $('#editor-fields input, #editor-fields select, #editor-fields textarea');
  if (input) input.focus();
}

function confirmAction(title, text, accept='Продолжить') {
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  $('#confirm-accept').textContent = accept;
  $('#confirm-dialog').showModal();
  return new Promise(resolve => {
    const finish = value => { $('#confirm-dialog').close(); cleanup(); resolve(value); };
    const submit = event => {event.preventDefault();finish(true);};
    const cancel = () => finish(false);
    const escape = event => {event.preventDefault();finish(false);};
    const cleanup = () => {$('#confirm-form').removeEventListener('submit', submit);$('#confirm-cancel').removeEventListener('click',cancel);$('#confirm-dialog').removeEventListener('cancel',escape);};
    $('#confirm-form').addEventListener('submit',submit);
    $('#confirm-cancel').addEventListener('click',cancel);
    $('#confirm-dialog').addEventListener('cancel',escape);
  });
}

$('#editor-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (!editor) return;
  const {kind,id} = editor;
  const fields = new FormData(event.target);
  let data;
  if (kind === 'entries') {
    data = {month:fields.get('month'), employee_id:Number(fields.get('employee_id')), project_id:Number(fields.get('project_id')), hours:fields.get('hours').trim(), closed:fields.get('closed') === 'true', note:fields.get('note')};
  } else {
    const key = kind === 'employees' ? 'role' : 'client';
    data = {name:fields.get('name'), [key]:fields.get(key), archived:fields.has('archived')};
  }
  $('#save-button').disabled = true;
  $('#form-error').hidden = true;
  try {
    await api(`/api/${kind}${id ? '/' + id : ''}`, id ? 'PUT' : 'POST', data);
    $('#editor').close();
    if (kind === 'entries' && data.month !== state.month) state.month = data.month;
    await load();
    toast('Сохранено');
  } catch (error) {
    $('#form-error').textContent = error.message;
    $('#form-error').hidden = false;
  } finally {$('#save-button').disabled = false;}
});

document.addEventListener('click', async event => {
  const button = event.target.closest('button');
  if (!button) return;
  const dataset = button.dataset;
  if (dataset.view) {state.view = dataset.view;render();}
  if (dataset.close !== undefined) $('#editor').close();
  if (dataset.newCatalog) openCatalog(dataset.newCatalog);
  if (dataset.editCatalog) openCatalog(state.view, Number(dataset.editCatalog));
  if (dataset.newEntry !== undefined) openEntry();
  if (dataset.editEntry) openEntry(Number(dataset.editEntry));
  if (dataset.status) {state.status = dataset.status;renderReport();}
  if (dataset.resetFilters !== undefined) {state.search = '';state.status = 'all';$('#search').value = '';renderReport();}
  if (dataset.deleteEntry) {
    if (loading || !state.loaded) return;
    const row = state.report.entries.find(r => r.id === Number(dataset.deleteEntry));
    if (await confirmAction('Удалить запись из отчёта?', `${row.project} · ${row.employee} · ${formatHours(row.hours)} ч. Проект и сотрудник останутся в справочниках.`, 'Удалить')) {
      try {await api('/api/entries/' + row.id, 'DELETE', {});await load();toast('Запись удалена');} catch(error) {toast(error.message);}
    }
  }
});

$('#primary-action').addEventListener('click', () => state.view === 'reports' ? openEntry() : openCatalog(state.view));
$('#month').addEventListener('change', event => {if (event.target.value && event.target.validity.valid) {state.month = event.target.value;load();}});
$('#employee-filter').addEventListener('change', event => {state.employee = event.target.value;load();});
$('#search').addEventListener('input', event => {state.search = event.target.value;renderReport();});
$('#retry').addEventListener('click',load);

function moveMonth(delta) {
  let [year, month] = state.month.split('-').map(Number);
  month += delta;
  if (month === 0) {year--;month=12;}
  if (month === 13) {year++;month=1;}
  if (year < 1 || year > 9999) return;
  state.month = `${String(year).padStart(4,'0')}-${String(month).padStart(2,'0')}`;
  load();
}
$('#prev-month').addEventListener('click',() => moveMonth(-1));
$('#next-month').addEventListener('click',() => moveMonth(1));
$('#month').min = '0001-01';
$('#month').max = '9999-12';

$('#copy-month').addEventListener('click', async () => {
  if (!await confirmAction('Перенести список проектов?', 'Добавим проекты прошлого месяца для выбранного сотрудника или всей команды. Часы будут равны нулю, статус — «Не закрыт». Уже существующие записи останутся как есть.', 'Перенести')) return;
  $('#copy-month').disabled = true;
  try {
    const result = await api('/api/copy', 'POST', {month:state.month, employee_id:state.employee ? Number(state.employee) : null});
    await load();
    toast(result.copied ? `Добавлено записей: ${result.copied}. Заполните часы за новый месяц.` : 'Нет новых проектов для переноса. Проверьте отчёт прошлого месяца.');
  } catch(error) {toast(error.message);} finally {$('#copy-month').disabled = false;}
});

$('#print').addEventListener('click', () => {
  const search = state.search, status = state.status;
  state.search = '';state.status = 'all';renderReport();
  window.print();
  state.search = search;state.status = status;renderReport();
});

load();
