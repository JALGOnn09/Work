#!/usr/bin/env python3
"""Team project hours. Python standard library only."""
import argparse
import csv
import io
import json
import os
import re
import sqlite3
from contextlib import contextmanager
from datetime import date
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent


class ValidationError(Exception):
    pass


def label(value, name, limit=160, required=True):
    if not isinstance(value, str) or len(value.strip()) > limit or (required and not value.strip()):
        raise ValidationError(f'{name}: укажите текст до {limit} символов.')
    return value.strip()


def month_value(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}', value):
        raise ValidationError('Укажите месяц в формате ГГГГ-ММ.')
    try:
        date.fromisoformat(value + '-01')
    except ValueError:
        raise ValidationError('Некорректный месяц.')
    return value


def number_id(value):
    if isinstance(value, bool) or not str(value).isdigit() or int(value) < 1:
        raise ValidationError('Некорректный идентификатор.')
    return int(value)


def hundredths(value):
    try:
        if isinstance(value, bool):
            raise InvalidOperation
        hours = Decimal(str(value).replace(',', '.'))
        if not hours.is_finite() or hours < 0 or hours > 744 or hours * 100 != (hours * 100).to_integral_value():
            raise InvalidOperation
        return int(hours * 100)
    except (InvalidOperation, ValueError):
        raise ValidationError('Часы: число от 0 до 744, не более двух знаков после запятой.')


def flag(value):
    if type(value) is not bool:
        raise ValidationError('Некорректный статус.')
    return int(value)


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY, name TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT '', archived INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY, name TEXT NOT NULL,
                    client TEXT NOT NULL DEFAULT '', archived INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS entries (
                    id INTEGER PRIMARY KEY, month TEXT NOT NULL,
                    employee_id INTEGER NOT NULL REFERENCES employees(id),
                    project_id INTEGER NOT NULL REFERENCES projects(id),
                    hours INTEGER NOT NULL CHECK(hours BETWEEN 0 AND 74400),
                    closed INTEGER NOT NULL CHECK(closed IN (0, 1)),
                    note TEXT NOT NULL DEFAULT '',
                    UNIQUE(month, employee_id, project_id));
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def catalog(self, kind):
        with self.connect() as db:
            return [dict(r) for r in db.execute(f'SELECT * FROM {kind} ORDER BY archived, name COLLATE NOCASE, id')]

    def save_catalog(self, kind, data, item_id=None):
        secondary = 'role' if kind == 'employees' else 'client'
        fields = (label(data.get('name'), 'Название', 1000 if kind == 'projects' else 160), label(data.get(secondary, ''), secondary, required=False), flag(data.get('archived', False)))
        with self.connect() as db:
            if item_id:
                cur = db.execute(f'UPDATE {kind} SET name=?, {secondary}=?, archived=? WHERE id=?', (*fields, item_id))
                if not cur.rowcount:
                    raise ValidationError('Запись не найдена.')
            else:
                item_id = db.execute(f'INSERT INTO {kind}(name, {secondary}, archived) VALUES (?, ?, ?)', fields).lastrowid
        return {'id': item_id}

    def report(self, month, employee=None):
        month = month_value(month)
        args = [month]
        where = 'e.month=?'
        if employee is not None:
            where += ' AND e.employee_id=?'
            args.append(number_id(employee))
        with self.connect() as db:
            rows = [dict(r) for r in db.execute(f'''SELECT e.*, p.name project, p.client,
                s.name employee FROM entries e JOIN projects p ON p.id=e.project_id
                JOIN employees s ON s.id=e.employee_id WHERE {where}
                ORDER BY s.name COLLATE NOCASE, p.name COLLATE NOCASE, e.id''', args)]
        closed = sum(r['hours'] for r in rows if r['closed'])
        pending = sum(r['hours'] for r in rows if not r['closed'])
        for row in rows:
            row['hours'] /= 100
            row['closed'] = bool(row['closed'])
        return {'entries': rows, 'totals': {'closed': closed / 100, 'pending': pending / 100,
            'all': (closed + pending) / 100, 'closed_count': sum(r['closed'] for r in rows),
            'count': len(rows)}}

    def save_entry(self, data, item_id=None):
        fields = (month_value(data.get('month')), number_id(data.get('employee_id')),
            number_id(data.get('project_id')), hundredths(data.get('hours')),
            flag(data.get('closed')), label(data.get('note', ''), 'Комментарий', 1000, False))
        try:
            with self.connect() as db:
                for table, key in [('employees', fields[1]), ('projects', fields[2])]:
                    ref = db.execute(f'SELECT archived FROM {table} WHERE id=?', (key,)).fetchone()
                    if ref is None:
                        raise ValidationError('Сотрудник или проект не найден.')
                    if ref['archived']:
                        previous = db.execute('SELECT employee_id, project_id, month FROM entries WHERE id=?', (item_id,)).fetchone() if item_id else None
                        old = previous['employee_id' if table == 'employees' else 'project_id'] if previous else None
                        if old != key or previous['month'] != fields[0]:
                            raise ValidationError('Архивную запись нельзя добавить в новый отчёт.')
                if item_id:
                    cur = db.execute('UPDATE entries SET month=?, employee_id=?, project_id=?, hours=?, closed=?, note=? WHERE id=?', (*fields, item_id))
                    if not cur.rowcount:
                        raise ValidationError('Запись не найдена.')
                else:
                    item_id = db.execute('INSERT INTO entries(month, employee_id, project_id, hours, closed, note) VALUES (?, ?, ?, ?, ?, ?)', fields).lastrowid
        except sqlite3.IntegrityError:
            raise ValidationError('Этот проект уже есть в отчёте сотрудника за выбранный месяц.')
        return {'id': item_id}

    def delete_entry(self, item_id):
        with self.connect() as db:
            if not db.execute('DELETE FROM entries WHERE id=?', (item_id,)).rowcount:
                raise ValidationError('Запись не найдена.')
        return {'ok': True}

    def copy_previous(self, data):
        month = month_value(data.get('month'))
        year, m = map(int, month.split('-'))
        if year == 1 and m == 1:
            raise ValidationError('Предыдущего месяца нет.')
        prev = f'{year - (m == 1):04d}-{12 if m == 1 else m - 1:02d}'
        employee = data.get('employee_id')
        args = [month, prev]
        where = ''
        if employee is not None:
            where = ' AND e.employee_id=?'
            args.append(number_id(employee))
        with self.connect() as db:
            cur = db.execute('''INSERT OR IGNORE INTO entries(month, employee_id, project_id, hours, closed, note)
                SELECT ?, e.employee_id, e.project_id, 0, 0, '' FROM entries e
                JOIN employees s ON s.id=e.employee_id JOIN projects p ON p.id=e.project_id
                WHERE e.month=? AND s.archived=0 AND p.archived=0''' + where, args)
            return {'copied': cur.rowcount}

    def backup(self):
        with self.connect() as db:
            # One read transaction provides a consistent snapshot during concurrent edits.
            db.execute('BEGIN')
            return {'version': 1, **{t: [dict(r) for r in db.execute(f'SELECT * FROM {t} ORDER BY id')]
                for t in ('employees', 'projects', 'entries')}}


def csv_cell(value):
    value = str(value)
    return "'" + value if value.lstrip().startswith(('=', '+', '-', '@')) else value


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f'{self.log_date_time_string()} {fmt % args}', flush=True)

    def send_bytes(self, value, content_type='application/json; charset=utf-8', status=200, filename=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(value)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        if filename:
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(value)

    def reply(self, data, status=200):
        self.send_bytes(json.dumps(data, ensure_ascii=False).encode(), status=status)

    def do_GET(self):
        try:
            path = urlsplit(self.path)
            params = parse_qs(path.query)
            month = params.get('month', [date.today().strftime('%Y-%m')])[0]
            employee = params.get('employee', [None])[0]
            if path.path == '/api/health':
                self.reply({'ok': True})
            elif path.path in ('/api/employees', '/api/projects'):
                self.reply(self.server.store.catalog(path.path.rsplit('/', 1)[1]))
            elif path.path == '/api/report':
                self.reply(self.server.store.report(month, employee))
            elif path.path == '/api/backup':
                self.send_bytes(json.dumps(self.server.store.backup(), ensure_ascii=False, indent=2).encode(), filename='project-hours-backup.json')
            elif path.path == '/api/export':
                report = self.server.store.report(month, employee)
                out = io.StringIO(newline='')
                writer = csv.writer(out, delimiter=';')
                writer.writerow(['Месяц', 'Сотрудник', 'Проект', 'Заказчик', 'Статус', 'Часы', 'Учтено в итоге', 'Комментарий'])
                for r in report['entries']:
                    writer.writerow([month, csv_cell(r['employee']), csv_cell(r['project']), csv_cell(r['client']),
                        'Закрыт' if r['closed'] else 'Не закрыт', str(r['hours']).replace('.', ','),
                        str(r['hours'] if r['closed'] else 0).replace('.', ','), csv_cell(r['note'])])
                writer.writerow(['', '', 'ИТОГО ПО ЗАКРЫТЫМ', '', '', '', str(report['totals']['closed']).replace('.', ',')])
                self.send_bytes(('\ufeff' + out.getvalue()).encode(), 'text/csv; charset=utf-8', filename=f'report-{month}.csv')
            else:
                files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/style.css': ('style.css', 'text/css'), '/favicon.svg': ('favicon.svg', 'image/svg+xml')}
                if path.path not in files:
                    self.reply({'error': 'Страница не найдена.'}, 404)
                    return
                name, mime = files[path.path]
                self.send_bytes((ROOT / 'static' / name).read_bytes(), mime + '; charset=utf-8')
        except ValidationError as exc:
            self.reply({'error': str(exc)}, 400)

    def mutate(self):
        try:
            origin = self.headers.get('Origin')
            if origin and urlsplit(origin).netloc != self.headers.get('Host'):
                self.reply({'error': 'Запрос с другого сайта запрещён.'}, 403)
                return
            if self.headers.get_content_type() != 'application/json':
                raise ValidationError('Ожидается JSON.')
            try:
                length = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                raise ValidationError('Некорректный размер запроса.')
            if not 0 < length <= 32000:
                raise ValidationError('Некорректный размер запроса.')
            try:
                data = json.loads(self.rfile.read(length))
            except (ValueError, UnicodeError):
                raise ValidationError('Некорректный JSON.')
            if not isinstance(data, dict):
                raise ValidationError('Ожидается объект JSON.')
            path = urlsplit(self.path).path
            match = re.fullmatch(r'/api/(employees|projects|entries)(?:/(\d+))?', path)
            if path == '/api/copy' and self.command == 'POST':
                result = self.server.store.copy_previous(data)
            elif match:
                kind, item = match.groups()
                item_id = number_id(item) if item else None
                if self.command == 'POST' and item_id is None:
                    result = self.server.store.save_entry(data) if kind == 'entries' else self.server.store.save_catalog(kind, data)
                elif self.command == 'PUT' and item_id is not None:
                    result = self.server.store.save_entry(data, item_id) if kind == 'entries' else self.server.store.save_catalog(kind, data, item_id)
                elif self.command == 'DELETE' and item_id is not None and kind == 'entries':
                    result = self.server.store.delete_entry(item_id)
                else:
                    self.reply({'error': 'Операция не найдена.'}, 404)
                    return
            else:
                self.reply({'error': 'Операция не найдена.'}, 404)
                return
            self.reply(result)
        except ValidationError as exc:
            self.reply({'error': str(exc)}, 400)
        except sqlite3.Error:
            self.reply({'error': 'Не удалось сохранить данные. Повторите попытку.'}, 500)

    do_POST = mutate
    do_PUT = mutate
    do_DELETE = mutate


def make_server(host, port, db_path):
    server = ThreadingHTTPServer((host, port), Handler)
    server.store = Store(db_path)
    return server


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Учёт проектных часов команды')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--db', default=os.environ.get('PROJECT_HOURS_DB', str(ROOT / '.data' / 'hours.sqlite3')))
    args = parser.parse_args()
    server = make_server(args.host, args.port, args.db)
    print(f'Project hours: listening on {args.host}:{server.server_port}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
