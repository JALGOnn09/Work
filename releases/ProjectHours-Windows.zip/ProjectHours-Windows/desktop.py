"""Local desktop launcher. Windows runtime is included in the portable build."""
import ctypes
from contextlib import closing
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sqlite3
import subprocess
import threading
import time
from urllib.parse import urlsplit
from urllib.request import build_opener, ProxyHandler
import uuid

from server import Handler, ROOT, make_server

LOG = logging.getLogger('project-hours-desktop')


def data_directory():
    local = os.environ.get('LOCALAPPDATA')
    if not local:
        raise RuntimeError('Не удалось определить папку данных Windows (LOCALAPPDATA).')
    return Path(local) / 'ProjectHours'


def migrate_database(destination, legacy):
    """Preserve the previous local version, including live WAL, using SQLite backup."""
    destination = Path(destination)
    legacy = Path(legacy)
    if destination.exists() or not legacy.is_file():
        return False
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.with_suffix('.migrating.sqlite3')
    try:
        with closing(sqlite3.connect(legacy.resolve().as_uri() + '?mode=ro', uri=True)) as source:
            with closing(sqlite3.connect(staging)) as target:
                source.backup(target)
                if target.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                    raise RuntimeError('Не удалось проверить прежнюю базу данных.')
        staging.replace(destination)
    finally:
        staging.unlink(missing_ok=True)
    return True


class DesktopHandler(Handler):
    def log_message(self, fmt, *args):
        LOG.info(fmt, *args)

    def do_GET(self):
        if urlsplit(self.path).path == '/api/health':
            self.reply({'ok': True, 'desktop_instance': self.server.desktop_instance})
        else:
            super().do_GET()


def active_instance(directory):
    """Never open an arbitrary URL from a stale state file."""
    try:
        state = json.loads((Path(directory) / 'desktop-state.json').read_text(encoding='utf-8'))
        url = urlsplit(state['url'])
        if url.scheme != 'http' or url.hostname != '127.0.0.1' or url.path != '/' or url.query or url.fragment or url.username or url.password:
            return None
        if not url.port or not 1 <= url.port <= 65535:
            return None
        # A local app must work even on computers configured with an HTTP proxy.
        opener = build_opener(ProxyHandler({}))
        with opener.open(state['url'] + 'api/health', timeout=1) as response:
            health = json.load(response)
        if health.get('ok') is True and health.get('desktop_instance') == state['instance']:
            return state['url']
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def browser_path():
    candidates = []
    for environment in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
        base = os.environ.get(environment)
        if base:
            candidates.extend([Path(base) / 'Microsoft/Edge/Application/msedge.exe',
                               Path(base) / 'Google/Chrome/Application/chrome.exe'])
    # Respect custom browser installations registered by Windows.
    if os.name == 'nt':
        import winreg
        for name in ('msedge.exe', 'chrome.exe'):
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                    try:
                        with winreg.OpenKey(hive, 'Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\' + name,
                                            0, winreg.KEY_READ | view) as key:
                            candidates.append(Path(winreg.QueryValueEx(key, None)[0]))
                    except OSError:
                        pass
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise RuntimeError('Для окна приложения нужен Microsoft Edge или Google Chrome. Установите один из этих браузеров и повторите запуск.')


def open_window(url, directory, executable=None):
    browser = executable or browser_path()
    args = [str(browser), '--app=' + url,
            '--user-data-dir=' + str(Path(directory) / 'window-profile'),
            '--no-first-run', '--no-default-browser-check', '--disable-background-mode',
            '--disable-features=msEdgeStartupBoost', '--disable-extensions']
    return subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def focus_window(pid):
    """Restore the existing Windows app instead of launching a second browser."""
    if os.name != 'nt' or type(pid) is not int or pid <= 0:
        return False
    from ctypes import wintypes
    user = ctypes.WinDLL('user32', use_last_error=True)
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
    user.EnumWindows.restype = wintypes.BOOL
    user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowThreadProcessId.restype = wintypes.DWORD
    user.IsWindowVisible.argtypes = [wintypes.HWND]
    user.IsWindowVisible.restype = wintypes.BOOL
    user.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user.SetForegroundWindow.argtypes = [wintypes.HWND]
    user.SetForegroundWindow.restype = wintypes.BOOL
    found = []

    @callback_type
    def visit(window, unused):
        owner = wintypes.DWORD()
        user.GetWindowThreadProcessId(window, ctypes.byref(owner))
        if owner.value == pid and user.IsWindowVisible(window):
            user.ShowWindow(window, 9)  # SW_RESTORE also restores minimized windows.
            user.SetForegroundWindow(window)
            found.append(window)
            return False
        return True

    user.EnumWindows(visit, 0)
    return bool(found)


def run_session(directory, open_browser=open_window, legacy=None):
    """Serve on a free loopback port for the lifetime of the dedicated app window."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    database = directory / 'hours.sqlite3'
    if legacy is not None:
        migrate_database(database, legacy)
    server = make_server('127.0.0.1', 0, database)
    server.RequestHandlerClass = DesktopHandler
    server.desktop_instance = uuid.uuid4().hex
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    state_path = directory / 'desktop-state.json'
    url = f'http://127.0.0.1:{server.server_port}/'
    state = {'url': url, 'instance': server.desktop_instance}
    thread.start()
    try:
        staging = state_path.with_suffix('.tmp')
        staging.write_text(json.dumps(state), encoding='utf-8')
        staging.replace(state_path)
        if active_instance(directory) != url:
            raise RuntimeError('Не удалось запустить локальное приложение.')
        process = open_browser(url, directory)
        state['browser_pid'] = getattr(process, 'pid', None)
        staging.write_text(json.dumps(state), encoding='utf-8')
        staging.replace(state_path)
        exit_code = process.wait()
        if exit_code:
            raise RuntimeError('Окно приложения завершилось с ошибкой. Попробуйте открыть приложение снова.')
    finally:
        server.shutdown()
        thread.join()
        server.server_close()
        state_path.unlink(missing_ok=True)


class WindowsInstance:
    """A named OS handle vanishes on process exit, including unexpected exits."""
    def __init__(self, directory):
        from ctypes import wintypes
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
        self.kernel.CreateMutexW.restype = wintypes.HANDLE
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.restype = wintypes.BOOL
        identity = hashlib.sha256(str(Path(directory).resolve()).casefold().encode()).hexdigest()[:24]
        self.handle = self.kernel.CreateMutexW(None, False, 'Local\\ProjectHours-' + identity)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        self.existing = ctypes.get_last_error() == 183

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


def error_dialog(message):
    if os.name == 'nt':
        from ctypes import wintypes
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.MessageBoxW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT]
        user.MessageBoxW.restype = ctypes.c_int
        user.MessageBoxW(None, message, 'Проектные часы', 0x10)
    else:
        raise RuntimeError(message)


def main():
    instance = None
    try:
        if os.name != 'nt':
            raise RuntimeError('Этот файл запуска предназначен для Windows 10 / 11.')
        directory = data_directory()
        directory.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(directory / 'desktop.log', maxBytes=1_000_000, backupCount=2, encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        LOG.setLevel(logging.INFO)
        LOG.addHandler(handler)
        instance = WindowsInstance(directory)
        if instance.existing:
            for _ in range(50):
                url = active_instance(directory)
                if url:
                    state = json.loads((directory / 'desktop-state.json').read_text(encoding='utf-8'))
                    if focus_window(state.get('browser_pid')):
                        return
                    open_window(url, directory)
                    return
                time.sleep(0.1)
            raise RuntimeError('Приложение уже запускается. Подождите несколько секунд и попробуйте открыть ярлык снова.')
        # Detect browser before starting services, so a missing browser is reported immediately.
        executable = browser_path()
        run_session(directory, lambda url, folder: open_window(url, folder, executable), ROOT / '.data/hours.sqlite3')
    except Exception as error:
        LOG.exception('Desktop launch failed')
        error_dialog(str(error))
    finally:
        if instance:
            instance.close()


if __name__ == '__main__':
    main()
